public abstract class LadderGame {
    public abstract void play(String start, String end);
}