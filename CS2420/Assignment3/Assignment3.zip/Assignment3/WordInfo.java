public abstract class WordInfo {
    public String word;
    public int moves;
    public String history;
}